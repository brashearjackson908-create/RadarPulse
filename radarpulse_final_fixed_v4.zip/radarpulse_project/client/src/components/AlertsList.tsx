/**
 * RadarPulse - Active Alerts List
 * Compact list of active NWS warnings shown in bottom-left
 * Design: Storm Chaser Field Terminal
 */

import { AlertTriangle, ChevronDown, ChevronUp } from "lucide-react";
import { getWarningStyle } from "@/lib/warningColors";
import { useState } from "react";

interface NWSAlert {
  id: string;
  event: string;
  headline: string;
  description: string;
  instruction?: string;
  severity: string;
  urgency: string;
  effective: string;
  expires: string;
  areaDesc: string;
}

interface AlertsListProps {
  alerts: NWSAlert[];
  onAlertClick: (alert: NWSAlert) => void;
}

// Priority order for sorting
const SEVERITY_ORDER: Record<string, number> = {
  extreme: 0,
  severe: 1,
  moderate: 2,
  minor: 3,
  unknown: 4,
};

export default function AlertsList({ alerts, onAlertClick }: AlertsListProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showAll, setShowAll] = useState(false);

  if (alerts.length === 0) return null;

  const sorted = [...alerts].sort((a, b) => {
    const styleA = getWarningStyle(a.event, a.description);
    const styleB = getWarningStyle(b.event, b.description);
    const severityDiff = (SEVERITY_ORDER[a.severity?.toLowerCase()] ?? 4) - (SEVERITY_ORDER[b.severity?.toLowerCase()] ?? 4);
    if (severityDiff !== 0) return severityDiff;
    return styleB.priority - styleA.priority;
  });

  const displayed = showAll ? sorted : sorted.slice(0, 8);

  // Count by event type
  const counts: Record<string, { count: number; color: string }> = {};
  for (const alert of alerts) {
    const style = getWarningStyle(alert.event, alert.description);
    if (!counts[alert.event]) {
      counts[alert.event] = { count: 0, color: style.strokeColor };
    }
    counts[alert.event].count++;
  }

  return (
    <div
      className="glass-panel rounded-lg overflow-hidden"
      style={{ width: "220px", maxHeight: isExpanded ? "320px" : "auto" }}
    >
      {/* Header */}
      <button
        className="w-full flex items-center justify-between px-3 py-2 hover:bg-white/05 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <AlertTriangle size={12} className="text-yellow-400 pulse-warning" />
          <span className="font-rajdhani font-bold text-xs tracking-wider text-white">
            ACTIVE ALERTS
          </span>
          <span
            className="text-xs font-mono-data px-1.5 py-0.5 rounded font-bold"
            style={{ background: "rgba(255,68,68,0.4)", color: "#ffaaaa", border: "1px solid rgba(255,100,100,0.5)" }}
          >
            {alerts.length}
          </span>
        </div>
        {isExpanded ? <ChevronDown size={12} className="text-white/40" /> : <ChevronUp size={12} className="text-white/40" />}
      </button>

      {isExpanded && (
        <>
          {/* Summary counts */}
          <div className="px-3 pb-2 flex flex-wrap gap-1 border-b border-white/08">
            {Object.entries(counts)
              .sort((a, b) => b[1].count - a[1].count)
              .slice(0, 5)
              .map(([event, { count, color }]) => (
                <div
                  key={event}
                  className="flex items-center gap-1 text-xs px-1.5 py-0.5 rounded"
                  style={{ background: `${color}22`, border: `1px solid ${color}44` }}
                >
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
                  <span style={{ color }}>{count}</span>
                </div>
              ))}
          </div>

          {/* Alert list */}
          <div className="overflow-y-auto" style={{ maxHeight: "200px" }}>
            {displayed.map((alert) => {
              const style = getWarningStyle(alert.event, alert.description);
              return (
                <button
                  key={alert.id}
                  onClick={() => onAlertClick(alert)}
                  className="w-full text-left px-3 py-2 border-b border-white/05 hover:bg-white/06 transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-sm flex-shrink-0"
                      style={{ background: style.strokeColor }}
                    />
                    <span
                      className="text-xs font-semibold truncate group-hover:text-white transition-colors"
                      style={{ color: style.strokeColor }}
                    >
                      {alert.event}
                    </span>
                  </div>
                  <div className="text-xs text-white/40 truncate pl-4 mt-0.5">
                    {alert.areaDesc?.split(";")[0] || ""}
                  </div>
                </button>
              );
            })}
          </div>

          {sorted.length > 8 && (
            <button
              onClick={() => setShowAll(!showAll)}
              className="w-full py-2 text-xs text-blue-400/70 hover:text-blue-400 transition-colors text-center"
            >
              {showAll ? "Show less" : `Show all ${sorted.length} alerts`}
            </button>
          )}
        </>
      )}
    </div>
  );
}
