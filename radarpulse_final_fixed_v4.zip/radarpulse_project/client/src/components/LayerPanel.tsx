/**
 * RadarPulse - Layer Control Panel
 * Left-side floating panel for radar product and overlay controls
 * Design: Storm Chaser Field Terminal
 */

import { Layers, Radio, AlertTriangle, CloudRain, ChevronLeft, ChevronRight, Map } from "lucide-react";
import { RADAR_PRODUCTS, NEXRAD_STATIONS, type RadarProduct, type RadarStation } from "@/lib/radarConfig";
import { WARNING_STYLES } from "@/lib/warningColors";
import { useState } from "react";

interface LayerPanelProps {
  isOpen: boolean;
  onToggle: () => void;
  selectedProduct: RadarProduct;
  onProductChange: (product: RadarProduct) => void;
  selectedStation: RadarStation;
  onStationChange: (station: RadarStation) => void;
  showWarnings: boolean;
  onToggleWarnings: () => void;
  showMCD: boolean;
  onToggleMCD: () => void;
  showMPD: boolean;
  onToggleMPD: () => void;
  showCounties: boolean;
  onToggleCounties: () => void;
  showStates: boolean;
  onToggleStates: () => void;
  showLightning: boolean;
  onToggleLightning: () => void;
  showMotionVectors: boolean;
  onToggleMotionVectors: () => void;
  nightVisionMode: boolean;
  onToggleNightVision: () => void;
  radarOpacity: number;
  onOpacityChange: (val: number) => void;
}

const PRODUCT_COLORS: Record<string, string> = {
  mrms_reflectivity: "#1e90ff",
  mrms_velocity: "#ff6b35",
};

// Key warning types to show in legend
const LEGEND_WARNINGS = [
  { key: "Tornado Warning", label: "Tornado Warning" },
  { key: "Tornado Warning (Observed)", label: "Tornado Warning (Obs.)" },
  { key: "Severe Thunderstorm Warning", label: "Severe Thunderstorm" },
  { key: "Severe Thunderstorm Warning (Observed)", label: "SVR (Obs./Tor. Possible)" },
  { key: "Flash Flood Warning", label: "Flash Flood Warning" },
  { key: "Flash Flood Warning (Observed)", label: "Flash Flood (Obs.)" },
  { key: "Flash Flood Emergency", label: "Flash Flood Emergency" },
  { key: "Flood Warning", label: "Flood Warning" },
  { key: "Special Weather Statement", label: "Special Wx Statement" },
  { key: "Tornado Watch", label: "Tornado Watch" },
  { key: "Severe Thunderstorm Watch", label: "SVR Watch" },
];

export default function LayerPanel({
  isOpen,
  onToggle,
  selectedProduct,
  onProductChange,
  selectedStation,
  onStationChange,
  showWarnings,
  onToggleWarnings,
  showMCD,
  onToggleMCD,
  showMPD,
  onToggleMPD,
  showCounties,
  onToggleCounties,
  showStates,
  onToggleStates,
  showLightning,
  onToggleLightning,
  showMotionVectors,
  onToggleMotionVectors,
  nightVisionMode,
  onToggleNightVision,
  radarOpacity,
  onOpacityChange,
}: LayerPanelProps) {
  const [activeTab, setActiveTab] = useState<"radar" | "overlays" | "legend">("radar");

  return (
    <>
      {/* Toggle button */}
      <button
        onClick={onToggle}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-[1001] glass-panel p-2 rounded-r-lg border-l-0 transition-all hover:bg-white/10"
        style={{ left: isOpen ? "280px" : "0px" }}
        title={isOpen ? "Close panel" : "Open layers"}
      >
        {isOpen ? <ChevronLeft size={14} className="text-white/60" /> : <ChevronRight size={14} className="text-white/60" />}
      </button>

      {/* Panel */}
      {isOpen && (
        <div
          className="slide-in-left absolute top-0 left-0 h-full z-[1000] flex flex-col"
          style={{ width: "280px" }}
        >
          <div className="glass-panel h-full flex flex-col overflow-hidden border-r border-white/10">
            {/* Header */}
            <div className="p-3 border-b border-white/10 flex items-center gap-2">
              <Layers size={14} className="text-blue-400" />
              <span className="font-rajdhani font-bold text-sm tracking-wider text-white/90">LAYER CONTROLS</span>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-white/10">
              {(["radar", "overlays", "legend"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider transition-colors ${
                    activeTab === tab
                      ? "text-blue-300 border-b-2 border-blue-300 bg-white/10"
                      : "text-white/60 hover:text-white/90 hover:bg-white/05"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="flex-1 overflow-y-auto">
              {/* RADAR TAB */}
              {activeTab === "radar" && (
                <div className="p-3 space-y-4">
                  {/* Product selector */}
                  <div>
                    <div className="text-xs text-white/50 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <Radio size={10} /> Radar Product
                    </div>
                    <div className="space-y-1">
                      {RADAR_PRODUCTS.map((product) => (
                        <button
                          key={product.id}
                          onClick={() => onProductChange(product)}
                          className={`w-full text-left rounded p-2 transition-all ${
                            selectedProduct.id === product.id
                              ? "bg-white/10 border border-white/15"
                              : "hover:bg-white/05 border border-transparent"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className="w-2 h-2 rounded-full flex-shrink-0"
                              style={{
                                background: PRODUCT_COLORS[product.id] || "#888",
                                boxShadow: selectedProduct.id === product.id
                                  ? `0 0 6px ${PRODUCT_COLORS[product.id] || "#888"}`
                                  : "none",
                              }}
                            />
                            <span className={`text-xs font-semibold ${selectedProduct.id === product.id ? "text-white" : "text-white/70"}`}>
                              {product.label}
                            </span>
                          </div>
                          {selectedProduct.id === product.id && (
                            <div className="text-xs text-white/40 mt-1 pl-4 leading-tight">
                              {product.description}
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Opacity */}
                  <div>
                    <div className="text-xs text-white/50 uppercase tracking-wider mb-2">
                      Radar Opacity: {Math.round(radarOpacity * 100)}%
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={radarOpacity}
                      onChange={(e) => onOpacityChange(parseFloat(e.target.value))}
                      className="w-full accent-blue-400"
                    />
                  </div>

                  {/* National Mode Info */}
                  <div className="rounded p-3" style={{ background: "rgba(76,175,80,0.15)", border: "1px solid rgba(76,175,80,0.3)" }}>
                    <div className="text-xs font-semibold text-green-300 mb-1">🌍 NATIONAL MODE</div>
                    <div className="text-xs text-white/60">Seamless MRMS coverage across entire USA. Auto-refreshes every minute.</div>
                  </div>
                </div>
              )}

              {/* OVERLAYS TAB */}
              {activeTab === "overlays" && (
                <div className="p-3 space-y-3">
                  <div className="text-xs text-white/50 uppercase tracking-wider mb-2 flex items-center gap-1">
                    <AlertTriangle size={10} /> Warning Overlays
                  </div>

                  {[
                    { label: "NWS Warnings", value: showWarnings, toggle: onToggleWarnings, color: "#ff4444", desc: "All active NWS watches, warnings & advisories" },
                    { label: "Mesoscale Discussions (MCD)", value: showMCD, toggle: onToggleMCD, color: "#cc44ff", desc: "SPC severe weather mesoscale discussions" },
                    { label: "Precip. Discussions (MPD)", value: showMPD, toggle: onToggleMPD, color: "#9933ff", desc: "WPC mesoscale precipitation discussions" },
                    { label: "Lightning Strikes", value: showLightning, toggle: onToggleLightning, color: "#ffff00", desc: "Real-time lightning detection overlay" },
                    { label: "Storm Motion Vectors", value: showMotionVectors, toggle: onToggleMotionVectors, color: "#00ff88", desc: "Predicted storm movement directions" },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="rounded p-3 cursor-pointer transition-all hover:bg-white/05"
                      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
                      onClick={item.toggle}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-2.5 h-2.5 rounded-sm"
                            style={{ background: item.value ? item.color : "#444", boxShadow: item.value ? `0 0 6px ${item.color}` : "none" }}
                          />
                          <span className={`text-xs font-semibold ${item.value ? "text-white/90" : "text-white/40"}`}>
                            {item.label}
                          </span>
                        </div>
                        <div
                          className={`w-8 h-4 rounded-full transition-colors relative ${item.value ? "bg-blue-600" : "bg-white/15"}`}
                        >
                          <div
                            className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${item.value ? "left-4" : "left-0.5"}`}
                          />
                        </div>
                      </div>
                      <div className="text-xs text-white/35 mt-1 pl-4">{item.desc}</div>
                    </div>
                  ))}

                  <div className="text-xs text-white/50 uppercase tracking-wider mt-4 mb-2 flex items-center gap-1">
                    <Map size={10} /> Map Overlays
                  </div>

                  {[
                    { label: "Map Labels", value: showCounties, toggle: onToggleCounties, desc: "City and place name labels" },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="rounded p-3 cursor-pointer transition-all hover:bg-white/05"
                      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
                      onClick={item.toggle}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-semibold ${item.value ? "text-white/90" : "text-white/40"}`}>
                          {item.label}
                        </span>
                        <div className={`w-8 h-4 rounded-full transition-colors relative ${item.value ? "bg-blue-600" : "bg-white/15"}`}>
                          <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${item.value ? "left-4" : "left-0.5"}`} />
                        </div>
                      </div>
                      <div className="text-xs text-white/35 mt-1">{item.desc}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* LEGEND TAB */}
              {activeTab === "legend" && (
                <div className="p-3 space-y-1">
                  <div className="text-xs text-white/50 uppercase tracking-wider mb-3">Warning Color Legend</div>

                  {LEGEND_WARNINGS.map(({ key, label }) => {
                    const style = WARNING_STYLES[key];
                    if (!style) return null;
                    return (
                      <div key={key} className="flex items-center gap-2 py-1">
                        <div
                          className="w-10 h-3 rounded-sm flex-shrink-0"
                          style={{
                            background: style.fillColor,
                            border: `1.5px solid ${style.strokeColor}`,
                            opacity: 0.9,
                          }}
                        />
                        <span className="text-xs text-white/70">{label}</span>
                      </div>
                    );
                  })}

                  <div className="border-t border-white/10 pt-3 mt-3">
                    <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Discussions</div>
                    <div className="flex items-center gap-2 py-1">
                      <div className="w-10 h-3 rounded-sm flex-shrink-0" style={{ background: "#9400d3", border: "1.5px dashed #cc44ff" }} />
                      <span className="text-xs text-white/70">Mesoscale Conv. Discussion</span>
                    </div>
                    <div className="flex items-center gap-2 py-1">
                      <div className="w-10 h-3 rounded-sm flex-shrink-0" style={{ background: "#6600cc", border: "1.5px dashed #9933ff" }} />
                      <span className="text-xs text-white/70">Mesoscale Precip. Discussion</span>
                    </div>
                  </div>

                  <div className="border-t border-white/10 pt-3 mt-3">
                    <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Line Styles</div>
                    <div className="flex items-center gap-2 py-1">
                      <div className="w-10 h-0.5 flex-shrink-0" style={{ background: "#fff", opacity: 0.6 }} />
                      <span className="text-xs text-white/70">Warning (solid)</span>
                    </div>
                    <div className="flex items-center gap-2 py-1">
                      <div className="w-10 h-0.5 flex-shrink-0" style={{ background: "#fff", opacity: 0.6, borderTop: "2px dashed rgba(255,255,255,0.5)" }} />
                      <span className="text-xs text-white/70">Watch (dashed)</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
