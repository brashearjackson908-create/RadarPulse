/**
 * RadarPulse - RadarMap Component
 * Design: Storm Chaser Field Terminal
 * Full-screen Leaflet map with MRMS National Mosaic tiles, NWS warning polygons, MCD/MPD overlays
 * Auto-refreshes every 1 minute to show latest storm positioning
 */

import { useEffect, useRef, useCallback } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { getIEMTileUrl, type RadarProduct, type RadarStation } from "@/lib/radarConfig";
import { getWarningStyle, MCD_STYLE, MPD_STYLE } from "@/lib/warningColors";

interface NWSAlert {
  id: string;
  event: string;
  headline: string;
  description: string;
  instruction?: string;
  severity: string;
  urgency: string;
  effective: string;
  expires: string;
  areaDesc: string;
  geometry?: GeoJSON.Geometry;
  parameters?: Record<string, string[]>;
}

interface MCDFeature {
  id: number;
  text: string;
  issue: string;
  expire: string;
  watch_confidence?: string;
  concerning?: string;
  geometry: GeoJSON.Geometry;
  type: "MCD" | "MPD";
}

interface RadarMapProps {
  station: RadarStation;
  product: RadarProduct;
  radarOpacity: number;
  showWarnings: boolean;
  showMCD: boolean;
  showMPD: boolean;
  showCounties: boolean;
  showStates: boolean;
  showLightning: boolean;
  showMotionVectors: boolean;
  nightVisionMode: boolean;
  onWarningClick: (alert: NWSAlert) => void;
  onMCDClick: (mcd: MCDFeature) => void;
  onLocalConditionsClick?: (coords: { lat: number; lon: number }) => void;
  onMapReady?: (map: L.Map) => void;
}

// Dark map tile options
const DARK_TILE_URL = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
const DARK_TILE_ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';

export default function RadarMap({
  station,
  product,
  radarOpacity,
  showWarnings,
  showMCD,
  showMPD,
  showCounties,
  showStates,
  showLightning,
  showMotionVectors,
  nightVisionMode,
  onWarningClick,
  onMCDClick,
  onLocalConditionsClick,
  onMapReady,
}: RadarMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const radarLayerRef = useRef<L.TileLayer | null>(null);
  const warningLayerRef = useRef<L.GeoJSON | null>(null);
  const mcdLayerRef = useRef<L.GeoJSON | null>(null);
  const mpdLayerRef = useRef<L.GeoJSON | null>(null);
  const countyLayerRef = useRef<L.TileLayer | null>(null);
  const stateLayerRef = useRef<L.TileLayer | null>(null);
  const lightningLayerRef = useRef<L.LayerGroup | null>(null);
  const motionVectorLayerRef = useRef<L.LayerGroup | null>(null);
  const alertsRef = useRef<NWSAlert[]>([]);
  const lastLightningFetchRef = useRef<number>(0);

  // Initialize map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [39.8283, -98.5795],
      zoom: 4,
      zoomControl: false,
      attributionControl: true,
    });

    // Dark base tile
    L.tileLayer(DARK_TILE_URL, {
      attribution: DARK_TILE_ATTRIBUTION,
      subdomains: "abcd",
      maxZoom: 19,
      opacity: 1,
    }).addTo(map);

    // Custom zoom control position
    L.control.zoom({ position: "bottomright" }).addTo(map);

    mapRef.current = map;
    if (onMapReady) onMapReady(map);

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update radar layer when station or product changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (radarLayerRef.current) {
      map.removeLayer(radarLayerRef.current);
      radarLayerRef.current = null;
    }

    const tileUrl = getIEMTileUrl(station.id, product);
    const radarLayer = L.tileLayer(tileUrl, {
      opacity: radarOpacity,
      zIndex: 200,
      tileSize: 256,
      attribution: `MRMS via <a href="https://mesonet.agron.iastate.edu/">IEM</a>`,
      // Transparent 1x1 pixel for missing tiles
      errorTileUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
    });

    radarLayer.addTo(map);
    radarLayerRef.current = radarLayer;
  }, [station.id, product.id]);

  // Update radar opacity without re-creating the layer
  useEffect(() => {
    if (radarLayerRef.current) {
      radarLayerRef.current.setOpacity(radarOpacity);
    }
  }, [radarOpacity]);

  // Labels overlay (CartoDB dark labels)
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (countyLayerRef.current) {
      map.removeLayer(countyLayerRef.current);
      countyLayerRef.current = null;
    }

    if (showCounties) {
      const labelLayer = L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png",
        {
          subdomains: "abcd",
          opacity: 0.75,
          zIndex: 400,
          attribution: '&copy; <a href="https://carto.com/attributions">CARTO</a>',
        }
      );
      labelLayer.addTo(map);
      countyLayerRef.current = labelLayer;
    }
  }, [showCounties]);

  // State/county borders overlay
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (stateLayerRef.current) {
      map.removeLayer(stateLayerRef.current);
      stateLayerRef.current = null;
    }

    if (showStates) {
      const stateLayer = L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png",
        {
          subdomains: "abcd",
          opacity: 0.3,
          zIndex: 50,
          attribution: '&copy; <a href="https://carto.com/attributions">CARTO</a>',
        }
      );
      stateLayer.addTo(map);
      stateLayerRef.current = stateLayer;
    }
  }, [showStates]);

  // Fetch and render NWS warnings
  const fetchWarnings = useCallback(async () => {
    const map = mapRef.current;
    if (!map) return;

    try {
      const response = await fetch(
        "https://api.weather.gov/alerts/active?status=actual",
        {
          headers: {
            "User-Agent": "RadarPulse/1.0 (storm-chaser-radar-app)",
            "Accept": "application/geo+json",
          },
        }
      );

      if (!response.ok) throw new Error(`NWS API error: ${response.status}`);
      const data = await response.json();

      if (warningLayerRef.current) {
        map.removeLayer(warningLayerRef.current);
        warningLayerRef.current = null;
      }

      const alerts: NWSAlert[] = [];

      // Sort features by priority (lower priority drawn first, higher on top)
      const features = (data.features || []).filter((f: any) => f.geometry);
      features.sort((a: any, b: any) => {
        const styleA = getWarningStyle(a.properties?.event || "", a.properties?.description || "");
        const styleB = getWarningStyle(b.properties?.event || "", b.properties?.description || "");
        return styleA.priority - styleB.priority;
      });

      const geoJsonLayer = L.geoJSON(
        { type: "FeatureCollection" as const, features } as GeoJSON.FeatureCollection,
        {
          style: (feature) => {
            const event = feature?.properties?.event || "";
            const desc = feature?.properties?.description || "";
            const style = getWarningStyle(event, desc);
            return {
              fillColor: style.fillColor,
              color: style.strokeColor,
              weight: style.weight,
              opacity: style.strokeOpacity,
              fillOpacity: style.fillOpacity,
              dashArray: event.toLowerCase().includes("watch") ? "6,4" : undefined,
            };
          },
          onEachFeature: (feature, layer) => {
            const props = feature.properties || {};
            const event = props.event || "Weather Alert";
            const style = getWarningStyle(event, props.description || "");
            const alert: NWSAlert = {
              id: props.id || feature.id as string || Math.random().toString(),
              event: event,
              headline: props.headline || event,
              description: props.description || "",
              instruction: props.instruction,
              severity: props.severity || "",
              urgency: props.urgency || "",
              effective: props.effective || "",
              expires: props.expires || "",
              areaDesc: props.areaDesc || "",
              geometry: feature.geometry,
              parameters: props.parameters,
            };
            alerts.push(alert);

            layer.on("click", () => onWarningClick(alert));
            layer.on("mouseover", (e) => {
              const l = e.target as L.Path;
              l.setStyle({ weight: style.weight + 1.5, fillOpacity: style.fillOpacity + 0.15 });
              L.popup({ className: "warning-tooltip", closeButton: false, offset: [0, -4] })
                .setLatLng(e.latlng)
                .setContent(`<strong>${style.label}</strong><br/><span style="font-size:10px;opacity:0.8">${props.areaDesc || ""}</span>`)
                .openOn(map);
            });
            layer.on("mouseout", (e) => {
              geoJsonLayer.resetStyle(e.target);
              map.closePopup();
            });
          },
        }
      );

      if (showWarnings) {
        geoJsonLayer.addTo(map);
      }
      warningLayerRef.current = geoJsonLayer;
      alertsRef.current = alerts;
    } catch (err) {
      console.warn("Failed to fetch NWS warnings:", err);
    }
  }, [showWarnings, onWarningClick]);

  // Fetch MCD from NOAA MapServer
  const fetchMCD = useCallback(async () => {
    const map = mapRef.current;
    if (!map) return;

    try {
      const url = "https://mapservices.weather.noaa.gov/vector/rest/services/outlooks/spc_mesoscale_discussion/MapServer/0/query?where=1%3D1&outFields=*&f=geojson&outSR=4326";
      const response = await fetch(url);
      if (!response.ok) throw new Error("MCD fetch failed");
      const data = await response.json();

      if (mcdLayerRef.current) {
        map.removeLayer(mcdLayerRef.current);
        mcdLayerRef.current = null;
      }

      const layer = L.geoJSON(data, {
        style: () => ({
          fillColor: MCD_STYLE.fillColor,
          color: MCD_STYLE.strokeColor,
          weight: MCD_STYLE.weight,
          opacity: MCD_STYLE.strokeOpacity,
          fillOpacity: MCD_STYLE.fillOpacity,
          dashArray: "4,4",
        }),
        onEachFeature: (feature, layer) => {
          const props = feature.properties || {};
          // Extract MD number from "MD 0506" format in props.name
          let mdNum = props.num || props.objectid || 0;
          if (props.name && props.name.includes("MD")) {
            const match = props.name.match(/MD\s*(\d+)/);
            if (match) mdNum = parseInt(match[1]);
          }
          
          // Extract discussion text from properties - try multiple field names
          let discussionText = props.text || props.popupinfo || props.discussion || "";
          // If text is empty, construct a URL to the SPC discussion
          if (!discussionText) {
            discussionText = `https://www.spc.noaa.gov/products/md/md${String(mdNum).padStart(4, '0')}.html`;
          }
          
          // Extract issue and expire times - try multiple field names
          let issueTime = "";
          let expireTime = "";
          
          // idp_filedate is the most reliable UTC timestamp from NOAA MapServer
          if (props.idp_filedate) {
            issueTime = new Date(props.idp_filedate).toISOString();
          } else if (props.issue) {
            issueTime = new Date(props.issue).toISOString();
          }
          
          // Extract expiration from folderpath like "MD 0506 Active Till 2145 UTC"
          if (props.folderpath && props.folderpath.includes("Till")) {
            const match = props.folderpath.match(/Till\s*(\d{4}\s*UTC)/i);
            if (match) expireTime = match[1];
          }
          
          if (!expireTime) {
            if (props.expire) expireTime = props.expire;
            else if (props.expiration) expireTime = props.expiration;
          }
          const mcd: MCDFeature = {
            id: mdNum,
            text: discussionText,
            issue: issueTime,
            expire: expireTime,
            watch_confidence: props.watch_confidence,
            concerning: props.concerning,
            geometry: feature.geometry,
            type: "MCD",
          };
          layer.on("click", () => onMCDClick(mcd));
          layer.on("mouseover", (e) => {
            const l = e.target as L.Path;
            l.setStyle({ weight: MCD_STYLE.weight + 1.5, fillOpacity: 0.25 });
            L.popup({ className: "warning-tooltip", closeButton: false })
              .setLatLng(e.latlng)
              .setContent(`<strong style="color:#cc44ff">MCD #${mcd.id}</strong><br/><span style="font-size:10px">Mesoscale Discussion</span>`)
              .openOn(map);
          });
          layer.on("mouseout", (e) => {
            (layer as L.GeoJSON).resetStyle(e.target);
            map.closePopup();
          });
        },
      });

      if (showMCD) layer.addTo(map);
      mcdLayerRef.current = layer;
    } catch (err) {
      console.warn("Failed to fetch MCD:", err);
    }
  }, [showMCD, onMCDClick]);

  // Fetch MPD from NOAA MapServer
  const fetchMPD = useCallback(async () => {
    const map = mapRef.current;
    if (!map) return;

    try {
      const url = "https://mapservices.weather.noaa.gov/vector/rest/services/outlooks/wpc_mpd/MapServer/0/query?where=1%3D1&outFields=*&f=geojson&outSR=4326";
      const response = await fetch(url);
      if (!response.ok) throw new Error("MPD fetch failed");
      const data = await response.json();

      if (mpdLayerRef.current) {
        map.removeLayer(mpdLayerRef.current);
        mpdLayerRef.current = null;
      }

      const layer = L.geoJSON(data, {
        style: () => ({
          fillColor: MPD_STYLE.fillColor,
          color: MPD_STYLE.strokeColor,
          weight: MPD_STYLE.weight,
          opacity: MPD_STYLE.strokeOpacity,
          fillOpacity: MPD_STYLE.fillOpacity,
          dashArray: "8,4",
        }),
        onEachFeature: (feature, layer) => {
          const props = feature.properties || {};
          // Extract MPD number from "MPD 0123" format in props.name
          let mdNum = props.objectid || 0;
          if (props.name && props.name.includes("MPD")) {
            const match = props.name.match(/MPD\s*(\d+)/);
            if (match) mdNum = parseInt(match[1]);
          }
          
          const expireMatch = (props.folderpath || "").match(/Till\s*(\d{4}\s*UTC)/i);
          const expireStr = expireMatch ? expireMatch[1] : "";
          
          let discussionText = props.popupinfo || props.text || props.discussion || "";
          if (!discussionText) {
            discussionText = `https://www.wpc.ncep.noaa.gov/discussions/nfdsnt${String(mdNum).padStart(4, '0')}.html`;
          }
          
          let issueTime = "";
          if (props.idp_filedate) {
            issueTime = new Date(props.idp_filedate).toISOString();
          } else if (props.issue) {
            issueTime = new Date(props.issue).toISOString();
          }
          
          let expireTime = expireStr;
          if (!expireTime) {
            if (props.expire) expireTime = props.expire;
            else if (props.expiration) expireTime = props.expiration;
          }
          const mpd: MCDFeature = {
            id: mdNum,
            text: discussionText,
            issue: issueTime,
            expire: expireTime,
            concerning: props.folderpath || props.name || "",
            geometry: feature.geometry,
            type: "MPD",
          };
          layer.on("click", () => onMCDClick(mpd));
          layer.on("mouseover", (e) => {
            const l = e.target as L.Path;
            l.setStyle({ weight: MPD_STYLE.weight + 1.5, fillOpacity: 0.3 });
            L.popup({ className: "warning-tooltip", closeButton: false })
              .setLatLng(e.latlng)
              .setContent(`<strong style="color:#9933ff">MPD #${mpd.id}</strong><br/><span style="font-size:10px">Mesoscale Precipitation Discussion</span>`)
              .openOn(map);
          });
          layer.on("mouseout", (e) => {
            (layer as L.GeoJSON).resetStyle(e.target);
            map.closePopup();
          });
        },
      });

      if (showMPD) layer.addTo(map);
      mpdLayerRef.current = layer;
    } catch (err) {
      console.warn("Failed to fetch MPD:", err);
    }
  }, [showMPD, onMCDClick]);

  // Show/hide warning layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !warningLayerRef.current) return;
    if (showWarnings) {
      warningLayerRef.current.addTo(map);
    } else {
      map.removeLayer(warningLayerRef.current);
    }
  }, [showWarnings]);

  // Show/hide MCD layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mcdLayerRef.current) return;
    if (showMCD) {
      mcdLayerRef.current.addTo(map);
    } else {
      map.removeLayer(mcdLayerRef.current);
    }
  }, [showMCD]);

  // Show/hide MPD layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mpdLayerRef.current) return;
    if (showMPD) {
      mpdLayerRef.current.addTo(map);
    } else {
      map.removeLayer(mpdLayerRef.current);
    }
  }, [showMPD]);

  // Fetch lightning data from NOAA
  const fetchLightning = useCallback(async () => {
    const map = mapRef.current;
    if (!map || !showLightning) return;

    try {
      // Use NOAA's lightning data endpoint
      const response = await fetch(
        "https://mapservices.weather.noaa.gov/vector/rest/services/nowcoast/MapServer/26/query?where=1%3D1&outFields=*&f=geojson&outSR=4326&resultRecordCount=5000"
      );
      if (!response.ok) throw new Error("Lightning fetch failed");
      const data = await response.json();

      if (lightningLayerRef.current) {
        map.removeLayer(lightningLayerRef.current);
        lightningLayerRef.current = null;
      }

      const group = L.layerGroup();
      (data.features || []).forEach((feature: any) => {
        const coords = feature.geometry.coordinates;
        const marker = L.circleMarker([coords[1], coords[0]], {
          radius: 3,
          fillColor: "#ffff00",
          color: "#ffff00",
          weight: 1,
          opacity: 0.8,
          fillOpacity: 0.6,
        });
        marker.bindPopup(`<strong style="color:#ffff00">Lightning Strike</strong><br/>Lat: ${coords[1].toFixed(3)}<br/>Lon: ${coords[0].toFixed(3)}`);
        group.addLayer(marker);
      });

      group.addTo(map);
      lightningLayerRef.current = group;
      lastLightningFetchRef.current = Date.now();
    } catch (err) {
      console.warn("Failed to fetch lightning:", err);
    }
  }, [showLightning]);

  // Fetch and render storm motion vectors
  const fetchMotionVectors = useCallback(async () => {
    const map = mapRef.current;
    if (!map || !showMotionVectors) return;

    try {
      // Use NOAA's storm tracking data
      const response = await fetch(
        "https://mapservices.weather.noaa.gov/vector/rest/services/nowcoast/MapServer/25/query?where=1%3D1&outFields=*&f=geojson&outSR=4326&resultRecordCount=1000"
      );
      if (!response.ok) throw new Error("Motion vectors fetch failed");
      const data = await response.json();

      if (motionVectorLayerRef.current) {
        map.removeLayer(motionVectorLayerRef.current);
        motionVectorLayerRef.current = null;
      }

      const group = L.layerGroup();
      (data.features || []).forEach((feature: any) => {
        if (feature.geometry.type === "LineString") {
          const coords = feature.geometry.coordinates;
          const polyline = L.polyline(
            coords.map((c: any) => [c[1], c[0]]),
            {
              color: "#00ff88",
              weight: 2,
              opacity: 0.7,
              dashArray: "5,5",
            }
          );
          polyline.bindPopup(`<strong style="color:#00ff88">Storm Motion Vector</strong>`);
          group.addLayer(polyline);
        }
      });

      group.addTo(map);
      motionVectorLayerRef.current = group;
    } catch (err) {
      console.warn("Failed to fetch motion vectors:", err);
    }
  }, [showMotionVectors]);

  // Show/hide lightning layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (showLightning && lightningLayerRef.current) {
      lightningLayerRef.current.addTo(map);
      fetchLightning();
    } else if (!showLightning && lightningLayerRef.current) {
      map.removeLayer(lightningLayerRef.current);
    }
  }, [showLightning, fetchLightning]);

  // Show/hide motion vector layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (showMotionVectors && motionVectorLayerRef.current) {
      motionVectorLayerRef.current.addTo(map);
      fetchMotionVectors();
    } else if (!showMotionVectors && motionVectorLayerRef.current) {
      map.removeLayer(motionVectorLayerRef.current);
    }
  }, [showMotionVectors, fetchMotionVectors]);

  // Initial data fetch and 1-minute auto-refresh
  useEffect(() => {
    fetchMCD();
    fetchMPD();
    fetchLightning();
    fetchMotionVectors();
    fetchWarnings(); // Fetch warnings LAST so they appear on top for better clickability

    // Refresh radar tiles and warnings every 1 minute
    const interval = setInterval(() => {
      // Refresh radar tiles by redrawing the layer
      if (radarLayerRef.current) {
        radarLayerRef.current.redraw();
      }
      // Refresh warnings and overlays
      fetchMCD();
      fetchMPD();
      fetchLightning();
      fetchMotionVectors();
      fetchWarnings(); // Fetch warnings LAST so they appear on top for better clickability
    }, 60000); // 60000 ms = 1 minute

    return () => clearInterval(interval);
  }, [fetchWarnings, fetchMCD, fetchMPD, fetchLightning, fetchMotionVectors]);

  // Apply night vision mode styling to map
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const container = map.getContainer() as HTMLElement;
    if (nightVisionMode) {
      container.style.filter = "invert(1) hue-rotate(180deg) brightness(0.9)";
    } else {
      container.style.filter = "none";
    }
  }, [nightVisionMode]);

  return (
    <div
      ref={mapContainerRef}
      className="w-full h-full"
      style={{ background: nightVisionMode ? "#1a1a00" : "#050d1a" }}
    />
  );
}
