/**
 * RadarPulse - Main Application Page
 * Design: Storm Chaser Field Terminal
 * Full-screen radar map with floating glassmorphism panels
 */

import { useState, useCallback, useEffect, useRef } from "react";
import RadarMap from "@/components/RadarMap";
import TopBar from "@/components/TopBar";
import LayerPanel from "@/components/LayerPanel";
import WarningPanel from "@/components/WarningPanel";
import AlertsList from "@/components/AlertsList";
import RadarLegend from "@/components/RadarLegend";
import { RADAR_PRODUCTS, NEXRAD_STATIONS, DEFAULT_STATION, DEFAULT_PRODUCT, type RadarProduct, type RadarStation } from "@/lib/radarConfig";
import { getWarningStyle } from "@/lib/warningColors";
import { RefreshCw } from "lucide-react";

interface NWSAlert {
  id: string;
  event: string;
  headline: string;
  description: string;
  instruction?: string;
  severity: string;
  urgency: string;
  effective: string;
  expires: string;
  areaDesc: string;
  geometry?: GeoJSON.Geometry;
  parameters?: Record<string, string[]>;
}

interface MCDFeature {
  id: number;
  text: string;
  issue: string;
  expire: string;
  watch_confidence?: string;
  concerning?: string;
  geometry: GeoJSON.Geometry;
  type: "MCD" | "MPD";
}

export default function Home() {
  // Radar state
  const [selectedProduct, setSelectedProduct] = useState<RadarProduct>(DEFAULT_PRODUCT);
  const [selectedStation, setSelectedStation] = useState<RadarStation>(
    NEXRAD_STATIONS.find((s) => s.id === DEFAULT_STATION) || NEXRAD_STATIONS[0]
  );
  const [radarOpacity, setRadarOpacity] = useState(0.85);

  // Layer visibility
  const [showWarnings, setShowWarnings] = useState(true);
  const [showMCD, setShowMCD] = useState(true);
  const [showMPD, setShowMPD] = useState(true);
  const [showCounties, setShowCounties] = useState(true);
  const [showStates, setShowStates] = useState(true);
  const [showLightning, setShowLightning] = useState(true);
  const [showMotionVectors, setShowMotionVectors] = useState(true);
  const [nightVisionMode, setNightVisionMode] = useState(false);

  // UI state
  const [layerPanelOpen, setLayerPanelOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<NWSAlert | null>(null);
  const [selectedMCD, setSelectedMCD] = useState<MCDFeature | null>(null);
  const [localConditions, setLocalConditions] = useState<{ lat: number; lon: number; temp?: number; wind?: number; pressure?: number } | null>(null);

  // Warning data
  const [activeAlerts, setActiveAlerts] = useState<NWSAlert[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [nwsError, setNwsError] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const refreshMapRef = useRef<(() => void) | null>(null);
  const [lastLightningUpdate, setLastLightningUpdate] = useState<Date | null>(null);

  // Track online status via browser navigator.onLine (true network connectivity)
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Fetch active alerts for the sidebar list
  const fetchActiveAlerts = useCallback(async () => {
    try {
      setIsRefreshing(true);
      const response = await fetch(
        "https://api.weather.gov/alerts/active?status=actual",
        {
          headers: {
            "User-Agent": "RadarPulse/1.0 (storm-chaser-radar-app)",
            "Accept": "application/geo+json",
          },
        }
      );
      if (!response.ok) throw new Error("Failed to fetch alerts");
      const data = await response.json();

      const alerts: NWSAlert[] = (data.features || []).map((f: any) => ({
        id: f.properties?.id || f.id || Math.random().toString(),
        event: f.properties?.event || "Weather Alert",
        headline: f.properties?.headline || "",
        description: f.properties?.description || "",
        instruction: f.properties?.instruction,
        severity: f.properties?.severity || "",
        urgency: f.properties?.urgency || "",
        effective: f.properties?.effective || "",
        expires: f.properties?.expires || "",
        areaDesc: f.properties?.areaDesc || "",
        geometry: f.geometry,
        parameters: f.properties?.parameters,
      }));

      setActiveAlerts(alerts);
      setLastUpdated(new Date());
      setNwsError(false);
    } catch (err) {
      console.warn("Failed to fetch active alerts:", err);
      setNwsError(true);
      // Don't set isOnline=false — NWS API failures don't mean we're offline
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchActiveAlerts();
    const interval = setInterval(fetchActiveAlerts, 120000);
    return () => clearInterval(interval);
  }, [fetchActiveAlerts]);

  // Compute top warning types for top bar
  const topWarnings = (() => {
    const counts: Record<string, { count: number; color: string }> = {};
    for (const alert of activeAlerts) {
      const style = getWarningStyle(alert.event, alert.description);
      if (!counts[alert.event]) {
        counts[alert.event] = { count: 0, color: style.strokeColor };
      }
      counts[alert.event].count++;
    }
    return Object.entries(counts)
      .sort((a, b) => {
        const styleA = getWarningStyle(a[0]);
        const styleB = getWarningStyle(b[0]);
        return styleB.priority - styleA.priority;
      })
      .slice(0, 5)
      .map(([event, { count, color }]) => ({ event, count, color }));
  })();

  const handleWarningClick = useCallback((alert: NWSAlert) => {
    setSelectedMCD(null);
    setSelectedAlert(alert);
  }, []);

  const handleMCDClick = useCallback((mcd: MCDFeature) => {
    setSelectedAlert(null);
    setSelectedMCD(mcd);
  }, []);

  const handleClosePanel = useCallback(() => {
    setSelectedAlert(null);
    setSelectedMCD(null);
  }, []);

  const handleRefresh = useCallback(() => {
    fetchActiveAlerts();
    // Also refresh the radar tile by forcing re-render
    if (refreshMapRef.current) refreshMapRef.current();
  }, [fetchActiveAlerts]);

  const rightPanelOpen = !!(selectedAlert || selectedMCD);

  return (
    <div className="w-full h-full relative overflow-hidden" style={{ background: "#050d1a" }}>
      {/* Full-screen map */}
      <div className="absolute inset-0">
        <RadarMap
          station={selectedStation}
          product={selectedProduct}
          radarOpacity={radarOpacity}
          showWarnings={showWarnings}
          showMCD={showMCD}
          showMPD={showMPD}
          showCounties={showCounties}
          showStates={showStates}
          showLightning={showLightning}
          showMotionVectors={showMotionVectors}
          nightVisionMode={nightVisionMode}
          onWarningClick={handleWarningClick}
          onMCDClick={handleMCDClick}
          onLocalConditionsClick={setLocalConditions}
        />
      </div>

      {/* Top bar */}
      <TopBar
        stationId={selectedStation.id}
        stationName={selectedStation.name}
        productLabel={selectedProduct.label}
        activeWarningCount={activeAlerts.length}
        topWarnings={topWarnings}
        lastUpdated={lastUpdated}
        isOnline={isOnline}
        isRefreshing={isRefreshing}
        onRefresh={handleRefresh}
      />

      {/* Layer panel (left) */}
      <div className="absolute top-12 left-0 bottom-0 z-[999]">
        <LayerPanel
          isOpen={layerPanelOpen}
          onToggle={() => setLayerPanelOpen(!layerPanelOpen)}
          selectedProduct={selectedProduct}
          onProductChange={setSelectedProduct}
          selectedStation={selectedStation}
          onStationChange={setSelectedStation}
          showWarnings={showWarnings}
          onToggleWarnings={() => setShowWarnings(!showWarnings)}
          showMCD={showMCD}
          onToggleMCD={() => setShowMCD(!showMCD)}
          showMPD={showMPD}
          onToggleMPD={() => setShowMPD(!showMPD)}
          showCounties={showCounties}
          onToggleCounties={() => setShowCounties(!showCounties)}
              showStates={showStates}
              onToggleStates={() => setShowStates(!showStates)}
              showLightning={showLightning}
              onToggleLightning={() => setShowLightning(!showLightning)}
              showMotionVectors={showMotionVectors}
              onToggleMotionVectors={() => setShowMotionVectors(!showMotionVectors)}
              nightVisionMode={nightVisionMode}
              onToggleNightVision={() => setNightVisionMode(!nightVisionMode)}
              radarOpacity={radarOpacity}
              onOpacityChange={setRadarOpacity}
            />
      </div>

      {/* Warning detail panel (right) */}
      <div className="absolute top-12 right-0 bottom-0 z-[999]">
        <WarningPanel
          alert={selectedAlert}
          mcd={selectedMCD}
          onClose={handleClosePanel}
        />
      </div>

      {/* Active alerts list — positioned to avoid layer panel */}
      <div
        className="absolute bottom-8 z-[998]"
        style={{
          left: layerPanelOpen ? "296px" : "16px",
          right: rightPanelOpen ? "396px" : "auto",
          transition: "left 0.22s ease, right 0.22s ease",
          pointerEvents: "none",
        }}
      >
        <div style={{ pointerEvents: "all" }}>
          <AlertsList
            alerts={activeAlerts}
            onAlertClick={handleWarningClick}
          />
        </div>
      </div>

      {/* Radar legend (top right) — avoid blocking alerts */}
      <div
        className="absolute top-12 z-[1000]"
        style={{
          right: rightPanelOpen ? "396px" : "12px",
          transition: "right 0.22s ease",
        }}
      >
        <RadarLegend product={selectedProduct} />
      </div>

      {/* Data source attribution */}
      <div
        className="absolute bottom-1 left-1/2 -translate-x-1/2 z-[997] text-xs text-white/20 font-mono-data whitespace-nowrap"
        style={{ pointerEvents: "none" }}
      >
        NEXRAD via IEM • NWS Warnings via api.weather.gov • MCD/MPD via NOAA MapServices
      </div>
    </div>
  );
}
